import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "com.bmw.e30.infotainment",
  appName: "BMW E30",
  webDir: "dist",
  server: { androidScheme: "https", cleartext: true, allowNavigation: ["*.youtube.com","*.google.com","*.googleapis.com","*.gstatic.com"] },
  android: { allowMixedContent: true },
  plugins: { StatusBar: { style: "Dark", backgroundColor: "#080a0d" } }
};
export default config;